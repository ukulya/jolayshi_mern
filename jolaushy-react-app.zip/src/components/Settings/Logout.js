import React from "react";
import CommonNavbar from "../CommonNavbar/CommonNavbar";

const Logout = (props)=>{
    return(
        <div>
            <CommonNavbar/>
            <div className="container">

            </div>
        </div>
    )
}

export default Logout;