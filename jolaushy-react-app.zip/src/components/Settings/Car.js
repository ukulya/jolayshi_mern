import React from "react";
import CommonNavbar from "../CommonNavbar/CommonNavbar";

const Car = (props)=>{
    return(
        <div>
            <CommonNavbar/>
            <div className="container">

            </div>
        </div>
    )
}

export default Car;